
public class Tree {
	Node root;

	public Tree() {
		root = null;
	}

	public Node find(int empNo) {

		Node current = root;
		while (current.empNo != empNo) {
			if (empNo < current.empNo)
				current = current.leftChild;
			else
				current = current.rightChild;
			if (current == null)
				return null;
		}
		return current;

	}

	public void insert(int empNo, String name) {

		Node newNode = new Node();
		newNode.empNo = empNo;
		newNode.empName = name;
		if (root == null) // no node in root
			root = newNode;
		else // root occupied
		{
			Node current = root; // start at root
			Node parent;
			while (true) {
				parent = current;

				if (empNo < current.empNo) // go left
				{
					current = current.leftChild;
					if (current == null) {
						parent.leftChild = newNode;
						return;
					}
				} else // go right
				{
					current = current.rightChild;
					if (current == null) {
						parent.rightChild = newNode;
						return;
					}
				}
			}
		}
	}

	public void inOrder(Node localRoot) {
		if (localRoot != null) {
			inOrder(localRoot.leftChild);
			localRoot.displayNode();
			inOrder(localRoot.rightChild);
		}
	}

	public void preOrder(Node localRoot) {
		if (localRoot != null) {
			localRoot.displayNode();
			preOrder(localRoot.leftChild);
			preOrder(localRoot.rightChild);
		}
	}

	public void postOrder(Node localRoot) {
		if (localRoot != null) {
			postOrder(localRoot.leftChild);
			postOrder(localRoot.rightChild);
			localRoot.displayNode();
		}
	}

	
	
	public Node findRecursive(Node localRoot, int empNo) {
		if(localRoot == null)
			return null;
		if(localRoot.empNo == empNo)
			return localRoot;
		else if(empNo < localRoot.empNo)
			return findRecursive(localRoot.leftChild, empNo);
		else
			return findRecursive(localRoot.rightChild, empNo);
	}

	
	
	public void deleteAll() {
		root = null;
	}

}
