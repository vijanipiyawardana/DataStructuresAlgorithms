
public class Node {
	
	public int empNo;		// data item
	public String empName; // data item 
	
	public Node leftChild; // this node’s left child
    public Node rightChild; //this node’s right child

	public Node() {
		this.leftChild = null;
		this.rightChild = null;
	}
	public Node(int no, String name) {
		this.empNo = no;
		this.empName = name;
		this.leftChild = null;
		this.rightChild = null;
	}
	
	public void displayNode() {
		System.out.println("Emp No: " + empNo);
		System.out.println("Emp Name: " + empName);
	}

}
