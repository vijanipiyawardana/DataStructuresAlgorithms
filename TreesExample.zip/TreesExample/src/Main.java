import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		int empNo;
		Node n;
		
		Scanner input = new Scanner(System.in);
		
		Tree tree = new Tree();
		tree.insert(149, "Anusha");
		tree.insert(167, "Kosala");
		tree.insert(47, "Dinusha");
		tree.insert(66, "Mihiri");
		tree.insert(159, "Jayani");
		tree.insert(118, "Nimal");
		tree.insert(195, "Nishantha");
		tree.insert(34, "Avodya");
		tree.insert(105, "Bimali");
		tree.insert(133, "Sampath");
		
		System.out.println("Pre order traversal");
		tree.preOrder(tree.root);
		
		System.out.println("In order traversal");
		tree.inOrder(tree.root);
		
		System.out.println("Post order traversal");
		tree.postOrder(tree.root);
		
		System.out.print("Enter employee number to search: ");
		empNo = input.nextInt();
		n = tree.find(empNo);
		if(n != null) {
			n.displayNode();
		}else {
			System.out.println("User does not exist in the tree..!");
		}
		
		System.out.println("Deleting tree...");
		tree.deleteAll();
		
		System.out.println("In order traversal after deleted");
		tree.inOrder(tree.root);
	}

}
